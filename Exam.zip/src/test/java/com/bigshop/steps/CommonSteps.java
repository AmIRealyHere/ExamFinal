package com.bigshop.steps;

import com.bigshop.pages.MainPage;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@AllArgsConstructor
public class CommonSteps {
    private final MainPage mainPage;
}
